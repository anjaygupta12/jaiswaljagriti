<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\Auth\AdminLoginController;
use App\Http\Controllers\HomeController;

Route::get('/',  [HomeController::class, 'index']);
Route::get('/about',  [HomeController::class, 'about'])->name('about');
Route::get('/job',  [HomeController::class, 'job'])->name('job');
Route::get('/youth-wing',  [HomeController::class, 'YouthWing'])->name('youth-wing');
Route::get('/executive-body',  [HomeController::class, 'ExecutiveBody'])->name('executive-body');
Route::get('/womens-wing',  [HomeController::class, 'womensWing'])->name('womens-wing');
Route::get('/events',  [HomeController::class, 'events'])->name('events');


Auth::routes();

   Route::get('/admin', [AdminLoginController::class, 'index'])
        ->name('admin.login');
    Route::get('/admin/login', [AdminLoginController::class, 'index'])
        ->name('admin.login');

    Route::post('/admin/login', [AdminLoginController::class, 'login'])
        ->name('admin.login.submit');

    /*
    |--------------------------------------------------------------------------
    | Admin Protected Routes
    |--------------------------------------------------------------------------
    */

    Route::middleware(['admin'])->group(function () {

        Route::get('/dashboard', function () {
            return view('admin.dashboard');
        })->name('admin.dashboard');

    });



Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
