<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            overflow-x: hidden;
            background: #f4f6f9;
        }

        .sidebar {
            min-height: 100vh;
            background: #343a40;
        }

        .sidebar .nav-link {
            color: #c2c7d0;
            padding: 12px 20px;
            font-size: 15px;
        }

        .sidebar .nav-link:hover {
            background: #495057;
            color: #fff;
        }

        .sidebar .nav-link.active {
            background: #007bff;
            color: #fff;
        }

        .content-area {
            padding: 20px;
        }

        .card-box {
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">

                <div class="text-center text-white py-4 border-bottom">
                    <h4 class="font-weight-bold mb-0">
                        Admin Panel
                    </h4>
                </div>

                <ul class="nav flex-column mt-3">

                    <li class="nav-item">
                        <a href="#" class="nav-link active">
                            <i class="fas fa-tachometer-alt mr-2"></i>
                            Dashboard
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-users mr-2"></i>
                            Users
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-shopping-cart mr-2"></i>
                            Orders
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-wallet mr-2"></i>
                            Transactions
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-chart-bar mr-2"></i>
                            Reports
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-cog mr-2"></i>
                            Settings
                        </a>
                    </li>

                    <li class="nav-item mt-4">
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf

                            <button type="submit"
                                class="btn btn-danger btn-block rounded-0">
                                <i class="fas fa-sign-out-alt mr-2"></i>
                                Logout
                            </button>
                        </form>
                    </li>

                </ul>

            </div>

            <!-- Main Content -->
            <div class="col-md-10">

                <!-- Top Navbar -->
                <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">

                    <h4 class="mb-0 font-weight-bold">
                        Dashboard
                    </h4>

                    <div class="ml-auto">
                        <span class="font-weight-bold text-primary">
                            Welcome Admin
                        </span>
                    </div>

                </nav>

                <!-- Content -->
                <div class="content-area">

                    <!-- Cards -->
                    <div class="row">

                        <div class="col-md-3 mb-4">
                            <div class="card shadow border-0 bg-primary text-white card-box">
                                <div class="card-body text-center">
                                    <i class="fas fa-users fa-3x mb-3"></i>
                                    <h3>150</h3>
                                    <p class="mb-0">Total Users</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-4">
                            <div class="card shadow border-0 bg-success text-white card-box">
                                <div class="card-body text-center">
                                    <i class="fas fa-shopping-cart fa-3x mb-3"></i>
                                    <h3>85</h3>
                                    <p class="mb-0">Orders</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-4">
                            <div class="card shadow border-0 bg-warning text-white card-box">
                                <div class="card-body text-center">
                                    <i class="fas fa-rupee-sign fa-3x mb-3"></i>
                                    <h3>₹25K</h3>
                                    <p class="mb-0">Revenue</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 mb-4">
                            <div class="card shadow border-0 bg-danger text-white card-box">
                                <div class="card-body text-center">
                                    <i class="fas fa-chart-line fa-3x mb-3"></i>
                                    <h3>12</h3>
                                    <p class="mb-0">Reports</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Table -->
                    <div class="card shadow border-0">

                        <div class="card-header bg-white">
                            <h5 class="mb-0 font-weight-bold">
                                Recent Activities
                            </h5>
                        </div>

                        <div class="card-body p-0">

                            <div class="table-responsive">

                                <table class="table table-bordered table-hover mb-0">

                                    <thead class="thead-dark">

                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>

                                    </thead>

                                    <tbody>

                                        <tr>
                                            <td>1</td>
                                            <td>Demo User</td>
                                            <td>
                                                <span class="badge badge-success">
                                                    Active
                                                </span>
                                            </td>
                                            <td>{{ date('d M Y') }}</td>
                                        </tr>

                                        <tr>
                                            <td>2</td>
                                            <td>John Doe</td>
                                            <td>
                                                <span class="badge badge-warning">
                                                    Pending
                                                </span>
                                            </td>
                                            <td>{{ date('d M Y') }}</td>
                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
