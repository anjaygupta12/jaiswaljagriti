    <!-- Main Header -->
    <div class="main-header">
        <div class="container-custom"
            style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
            <div class="logo-area">
                <img src="{{ asset('assets/images/logo-1024x212.jpg') }}" alt="Jaiswal Jagriti Logo"
                    onerror="this.src='https://placehold.co/1024x212?text=Jaiswal+Jagriti'">
            </div>
            <div style="display: flex; gap: 15px;">
                <a href="#" class="btn-primary" id="memberLoginBtn"><i class="fas fa-user-plus"></i> Members Login
                    / Registration</a>
                <a href="#" class="btn-primary" style="background: #0F172A;" id="donateBtn"><i
                        class="fas fa-donate"></i> Donate Now</a>
            </div>
        </div>
    </div>

    <!-- Navigation Bar -->
    <div class="navbar">
        <div class="container-custom" style="background-color:#e36108!important;" >
            <ul class="nav-links">
                <li><a href="/" class="active">Home</a></li>
                <li><a href="{{ route('about') }}">About</a></li>
                <li><a href="">Matrimonial</a></li>
                <li><a href="{{ route('job') }}">Job & Careers</a></li>
                <li><a href="{{ route('youth-wing') }}">Youth's Wing</a></li>
                <li><a href="{{ route('executive-body') }}">Executive Body</a></li>
                <li><a href="{{ route('womens-wing') }}">Women's Wing</a></li>
                <li><a href="{{ route('events') }}">Events</a></li>
                <li><a href="#">Subscription</a></li>
                <li><a href="#">Media Gallery</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
    </div>
