<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function index()
    {
        return view('home');
    }
    public function about()
    {
        return view('about');
    }
    public function job()
    {
        return view('job');
    }
        public function YouthWing()
    {
        return view('Youth_wing');
    }
  public function ExecutiveBody()
    {
        return view('executive_body');
    }
      public function womensWing()
    {
        return view('womens_wing');
    }
          public function events()
    {
        return view('events');
    }
}
